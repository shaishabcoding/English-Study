package com.shaishab316.englishstudy

data class Data(
    val text: String? = null, val image: Int? = null
)
